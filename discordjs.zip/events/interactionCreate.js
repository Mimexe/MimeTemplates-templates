import { error as _error } from "../logger.js";
import isDev from "../dev.js";
import { MimeEmbed, MimeEmbedType } from "../utils/MimeEmbed.js";

export const name = "interactionCreate";
export const once = false;
export async function execute(client, interaction) {
  if (!interaction.isChatInputCommand()) return;
  if (!client.fullReady) {
    await interaction.reply({
      embeds: [
        new MimeEmbed()
          .setType(MimeEmbedType.ERROR)
          .setTitle("Le bot n'est pas démarré !"),
      ],
      ephemeral: true,
    });
    return;
  }
  if (isDev() && interaction.user.id != "754038841001640099") {
    await interaction.reply({
      embeds: [
        new MimeEmbed()
          .setType(MimeEmbedType.ERROR)
          .setTitle("Le bot est en mode développement !"),
      ],
      ephemeral: true,
    });
    return;
  }

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    _error(`No command matching ${interaction.commandName} was found.`);
    return;
  }

  try {
    await command.execute(interaction);
  } catch (error) {
    _error("Error while executing command: " + error.stack);
    if (interaction.replied || interaction.deferred) {
      await interaction.editReply({
        content: `Une erreur est survenue lors de l'exécution de la commande !\n${error.message.replace(
          client.token,
          "TOK3N"
        )}`,
        embeds: [],
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: `Une erreur est survenue lors de l'exécution de la commande !\n${error.message.replace(
          client.token,
          "TOK3N"
        )}`,
        embeds: [],
        ephemeral: true,
      });
    }
  }
}
