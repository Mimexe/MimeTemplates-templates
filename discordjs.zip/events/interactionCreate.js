const { EmbedBuilder } = require("discord.js");
const { Client } = require("discord.js");
const logger = require("../logger");
const isDev = require("../dev");

module.exports = {
  name: "interactionCreate",
  once: false,
  /**
   *
   * @param {Client} client
   * @param {import("discord.js").Interaction} interaction
   * @returns
   */
  execute: async (client, interaction) => {
    if (!client.fullReady) {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle("Le bot n'est pas démarré !")
            .setColor("Red"),
        ],
        ephemeral: true,
      });
      return;
    }
    if (isDev && interaction.user.id != "<OWNER ID>") {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle("Le bot est en mode développement !")
            .setColor("Red"),
        ],
        ephemeral: true,
      });
      return;
    }
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);

    if (!command) {
      logger.error(`No command matching ${interaction.commandName} was found.`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      logger.error("Error while executing command: " + error.stack);
      if (interaction.replied || interaction.deferred) {
        await interaction.editReply({
          content: `Une erreur est survenue lors de l'exécution de la commande !\n${error.message.replace(
            client.token,
            "TOK3N"
          )}`,
          embeds: [],
          ephemeral: true,
        });
      } else {
        await interaction.reply({
          content: `Une erreur est survenue lors de l'exécution de la commande !\n${error.message.replace(
            client.token,
            "TOK3N"
          )}`,
          embeds: [],
          ephemeral: true,
        });
      }
    }
  },
};
