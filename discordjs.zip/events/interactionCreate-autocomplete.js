import isDev from "../dev.js";

export const name = "interactionCreate";
export const once = false;
export async function execute(client, interaction) {
  if (!interaction.isAutocomplete()) return;
  if (!client.fullReady) {
    return;
  }
  if (isDev() && interaction.user.id != "754038841001640099") {
    return;
  }
  const command = client.commands.get(interaction.commandName);

  if (!command) {
    console.error(`No command matching ${interaction.commandName} was found.`);
    return;
  }

  try {
    await command.autocomplete(interaction);
  } catch (error) {
    console.error(error);
  }
}
