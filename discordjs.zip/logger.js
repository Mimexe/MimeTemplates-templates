require("colors");
const isDev = require("./dev.js");

module.exports = {
  info: (msg) => {
    console.log(`${new Date().toLocaleTimeString()} [INFO] ${msg}`.blue);
  },
  warn: (msg) => {
    console.log(`${new Date().toLocaleTimeString()} [WARN] ${msg}`.yellow);
  },
  success: (msg) => {
    console.log(`${new Date().toLocaleTimeString()} [SUCCESS] ${msg}`.green);
  },
  error: (msg) => {
    console.log(`${new Date().toLocaleTimeString()} [ERROR] ${msg}`.red);
  },
  debug: (msg) => {
    if (isDev())
      console.log(`${new Date().toLocaleTimeString()} [DEBUG] ${msg}`.gray);
  },
};
