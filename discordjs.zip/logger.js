import "colors";
import isDev from "./dev.js";

export function info(msg) {
  console.log(`${new Date().toLocaleTimeString()} [INFO] ${msg}`.blue);
}
export function warn(msg) {
  console.log(`${new Date().toLocaleTimeString()} [WARN] ${msg}`.yellow);
}
export function success(msg) {
  console.log(`${new Date().toLocaleTimeString()} [SUCCESS] ${msg}`.green);
}
export function error(msg) {
  console.log(`${new Date().toLocaleTimeString()} [ERROR] ${msg}`.red);
}
export function debug(msg) {
  if (isDev())
    console.log(`${new Date().toLocaleTimeString()} [DEBUG] ${msg}`.gray);
}
