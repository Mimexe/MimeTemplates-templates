import { readFileSync, writeFileSync } from "fs";

class MimeCache {
  /**
   *
   * @param {String} file
   */
  constructor(file) {
    this.file = file;
    this.data = [];
    this.fetchData();
  }

  fetchData() {
    try {
      this.data = JSON.parse(readFileSync(this.file));
    } catch (err) {
      if (err.code == "ENOENT") {
        this.data = [];
        this.saveData();
        this.fetchData();
      } else {
        throw err;
      }
    }
  }

  saveData() {
    writeFileSync(this.file, JSON.stringify(this.data, null, 4));
  }

  /**
   *
   * @returns {Array}
   */
  get() {
    return this.data;
  }

  /**
   *
   * @param {Array} data
   */
  set(data) {
    if (!(data instanceof Array)) {
      throw new MimeCacheError("data must be type of Array", "WRONG_TYPE");
    }
    this.data = data;
    this.saveData();
  }
}

class MimeCacheError extends Error {
  constructor(message, code) {
    super();
    this.message = message;
    this.code = code;
  }
}

export default MimeCache;
