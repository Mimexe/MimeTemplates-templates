import { EmbedBuilder } from "discord.js";

class MimeEmbed extends EmbedBuilder {
  constructor() {
    super();
    /**
     * @type {MimeEmbedType}
     */
    this.type = null;
    this.footer = null;
    this.author = null;
    this.setType(MimeEmbedType.INFO);
    this.setFooter();
    this.setTimestamp();
  }

  /**
   *
   * @param {MimeEmbedType} type
   * @returns {MimeEmbed}
   */
  setType(type) {
    this.type = type;
    this.setColor(this.type.color);
    this.setAuthor(this.author);
    return this;
  }

  /**
   *
   * @param {import("discord.js").EmbedFooterOptions} options
   * @returns {MimeEmbed}
   */

  setFooter(options) {
    this.footer = options;
    super.setFooter({
      text: `<GUILD NAME>${options?.text ? ` • ${options.text}` : ""}`,
      iconURL: options?.iconURL,
    });
    return this;
  }

  /**
   *
   * @param {import("discord.js").EmbedAuthorOptions} options
   */
  setAuthor(options) {
    this.author = options;
    super.setAuthor({
      name: `${this.type.string}${options?.name ? ` • ${options.name}` : ""}`,
      iconURL: options?.iconURL ? options.iconURL : undefined,
      url: options?.url ? options.url : undefined,
    });
    return this;
  }

  // build() {
  //     return new EmbedBuilder(this);
  // }
}

class MimeEmbedType {
  static INFO = new MimeEmbedType("Information", "Blue");
  static SUCCESS = new MimeEmbedType("Succès", "Green");
  static ERROR = new MimeEmbedType("Erreur", "Red");
  static FATAL_ERROR = new MimeEmbedType("Erreur Fatal", "DarkRed");

  /**
   *
   * @param {String} string
   * @param {import("discord.js").ColorResolvable} color
   */
  constructor(string, color) {
    this.string = string;
    this.color = color;
  }

  toString() {
    return `${this.string} - ${this.color}`;
  }
}

export { MimeEmbed, MimeEmbedType };
