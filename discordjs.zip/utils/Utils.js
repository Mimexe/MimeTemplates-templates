/**
 *
 * @param {String} str
 * @returns {String}
 */
const firstUpper = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
};

/**
 *
 * @param {String} str
 * @returns {String}
 */
const removeParentheses = (str) => {
  return str.replaceAll(/\((.*)\)/g, "");
};

export { firstUpper, removeParentheses };
