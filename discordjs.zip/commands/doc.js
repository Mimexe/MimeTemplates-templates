import { SlashCommandBuilder, codeBlock } from "discord.js";
import { MimeEmbed, MimeEmbedType } from "../utils/MimeEmbed.js";
import {
  firstUpper,
  getCategory,
  getCategoryColor,
  removeParentheses,
} from "../utils/Utils.js";
import * as nodeHtmlMarkdown from "node-html-markdown";
const markdown = nodeHtmlMarkdown.NodeHtmlMarkdown.translate;
import similarity from "similarity";
import SkriptAPI from "../utils/SkriptAPI.js";
import { skript } from "../config.js";
const api = new SkriptAPI(skript);

export async function execute(interaction) {
  let group = interaction.options.getSubcommandGroup();
  let sub = interaction.options.getSubcommand();
  if (group == "skript") {
    if (sub == "article") {
      let query = interaction.options.getString("query");
      let id = parseInt(query);
      if (isNaN(id)) {
        await interaction.reply({
          embeds: [
            new MimeEmbed()
              .setType(MimeEmbedType.ERROR)
              .setTitle(
                "L'id d'un article est requis ! Utiliser l'autocomplétion"
              ),
          ],
        });
        return;
      }
      await interaction.deferReply();
      let article = await api.getSyntax(id);
      let embed = new MimeEmbed();
      embed.setType(MimeEmbedType.SUCCESS);
      embed.setTitle(article.name);
      embed.setAuthor({
        name: `Depuis ${firstUpper(article.addon)} ${article.version}`,
      });
      embed.setFooter({ text: "ID: " + article.id });
      embed.setDescription(
        markdown(article.content) + "\n\n*Données par skript-mc.fr*"
      );
      embed.setURL(article.documentationUrl);
      embed.setFields([
        { name: "Addon", value: `${firstUpper(article.addon)}` },
        {
          name: "Schéma(s)",
          value: `${codeBlock(
            "applescript",
            article.pattern.replace(/<\/?[^>]+>/g, "")
          )}`,
        },
        {
          name: "Catégorie",
          value: `${getCategoryColor(article.category)} ${getCategory(
            article.category
          )}`,
        },
        {
          name: "Exemple",
          value: `${
            codeBlock("applescript", markdown(article.example)).length > 1024
              ? codeBlock("applescript", markdown(article.example)).slice(
                  0,
                  1021
                ) + "```"
              : codeBlock("applescript", markdown(article.example))
          }`,
        },
        {
          name: "Dépréciée",
          value: `${
            article.deprecation
              ? `Oui depuis ${article.deprecation}\nAlternative: ${article.deprecationLink}`
              : "Non"
          }`,
        },
      ]);
      let embeds = [];
      embeds.push(embed);
      if (codeBlock("applescript", markdown(article.example)).length > 1024) {
        embeds.push(
          new MimeEmbed()
            .setType(MimeEmbedType.INFO)
            .setTitle(
              "L'exemple de cette article est trop important seulement 1024 caractères sont mis."
            )
        );
      }
      await interaction.editReply({
        embeds,
      });
    } else if (sub == "addon") {
      let query = interaction.options.getString("query");
      await interaction.deferReply();
      let article = await api.getAddon(query);
      let embed = new MimeEmbed();
      embed.setType(MimeEmbedType.SUCCESS);
      embed.setTitle(`${article.name} v${article.version}`);
      embed.setFooter({ text: "ID: " + article.id });
      embed.setDescription(
        article.description + "\n\n*Données par skript-mc.fr*"
      );
      embed.setURL(article.documentationUrl);
      if (article.github)
        embed.setAuthor({ name: article.github, url: article.github });
      if (article.slug) {
        embed.addFields({ name: "ID en mot", value: article.slug });
      }
      if (article.author) {
        embed.addFields({ name: "Auteur", value: `${article.author}` });
      }
      if (article.dependencies)
        embed.addFields({ name: "Dépendences", value: article.dependencies });
      await interaction.editReply({ embeds: [embed] });
    }
  }
}
export async function autocomplete(interaction) {
  let group = interaction.options.getSubcommandGroup();
  let sub = interaction.options.getSubcommand();
  if (group == "skript") {
    if (sub == "article") {
      let value = interaction.options.getFocused();
      let data = [];
      for (let t of interaction.client.cache.skript.syntaxes.get()) {
        t.similarity = similarity(removeParentheses(t.name), value);
        data.push(t);
      }
      let filtered = data.sort((a, b) => b.similarity - a.similarity);
      let respond = filtered.map((c) => ({
        name: `${firstUpper(c.addon)} - ${getCategoryColor(
          c.category
        )} ${removeParentheses(c.name)} (${
          Math.round(c.similarity * 10000) / 10000
        })`,
        value: `${c.id}`,
      }));
      if (respond.length > 25) {
        respond = respond.slice(0, 25);
      }
      respond[0].name = "⭐ " + respond[0].name;
      await interaction.respond(respond);
    } else if (sub == "addon") {
      let value = interaction.options.getFocused();
      /**
       * @type {import("../utils/SkriptAPI").SkriptAddonsResponse[]}
       */
      let data = [];
      for (let t of interaction.client.cache.skript.addons.get()) {
        t.similarity = similarity(t.name, value);
        data.push(t);
      }
      let filtered = data.sort((a, b) => b.similarity - a.similarity);
      let respond = filtered.map((c) => ({
        name: `${c.name} v${c.version}`,
        value: `${c.slug}`,
      }));
      respond[0].name = "⭐ " + respond[0].name;
      await interaction.respond(respond);
    }
  }
}

export const data = new SlashCommandBuilder()
  .setName("doc")
  .setDescription("Documentation des languages")
  .addSubcommandGroup((o) =>
    o
      .setName("skript")
      .setDescription("Documentation de Skript")
      .addSubcommand((a) =>
        a
          .setName("article")
          .setDescription("Récupérer un article.")
          .addStringOption((f) =>
            f
              .setName("query")
              .setDescription("Recherche")
              .setRequired(true)
              .setAutocomplete(true)
          )
      )
      .addSubcommand((a) =>
        a
          .setName("addon")
          .setDescription("Récupérer un addon.")
          .addStringOption((f) =>
            f
              .setName("query")
              .setDescription("Recherche")
              .setRequired(true)
              .setAutocomplete(true)
          )
      )
  );
