import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { skript as token } from "../config.js";
import axios from "axios";
import { debug, error as _error, warn } from "../logger.js";
import { MimeEmbed, MimeEmbedType } from "../utils/MimeEmbed.js";
import MimeCache from "../utils/MimeCache.js";
import SkriptAPI from "../utils/SkriptAPI.js";
import { skript } from "../config.js";

export const data = new SlashCommandBuilder()
  .setName("reloaddocs")
  .setDescription("Recharger les documentations")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);
export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });
  try {
    /**
     * @type {{skript: {syntaxes: MimeCache, addons: MimeCache}}}
     */
    const caches = interaction.client.cache;
    const skriptApi = new SkriptAPI(skript);
    const embed = new MimeEmbed()
      .setType(MimeEmbedType.SUCCESS)
      .setTitle("Recharger la documentation:");
    await skriptApi
      .getSyntaxes()
      .then((v) => {
        debug("Skript/Syntaxes is good");
        embed.addFields({ name: "Skript/Syntaxes", value: "✅ Succès" });
        caches.skript.syntaxes.set(v);
      })
      .catch((v) => {
        debug("Skript/Syntaxes is not good");
        _error(v);
        embed.addFields({ name: "Skript/Syntaxes", value: "❌ Erreur" });
      });
    await skriptApi
      .getAddons()
      .then((v) => {
        debug("Skript/Addons is good");
        embed.addFields({ name: "Skript/Addons", value: "✅ Succès" });
        caches.skript.addons.set(v);
      })
      .catch((v) => {
        debug("Skript/Addons is not good");
        _error(v);
        embed.addFields({ name: "Skript/Addons", value: "❌ Erreur" });
      });

    const me = await skriptApi.getMe();

    embed.setAuthor({
      name: `Blocage: ${me.rateLimitRemaining}/${me.rateLimitQuota}`,
    });

    if (me.rateLimitRemaining == 0) {
      embed.setAuthor({ name: "Bot bloqué !" });
      embed.setType(MimeEmbedType.ERROR);
    }

    await interaction.editReply({
      embeds: [embed],
    });
  } catch (err) {
    await interaction.editReply("Erreur...");
    if (err.constructor.name == "AxiosError") {
      /**
       * @type {axios.AxiosError}
       */
      const error = err;
      console.log(error.code);
      console.log(error.response.status);
      console.log(error.response.statusText);
      if (error.code == "ERR_BAD_RESPONSE") {
        warn(
          `[reloaddocs.js] ${error.response.status} ${error.response.statusText} RATELIMITED`
        );
        await interaction.editReply({
          content: "",
          embeds: [
            new MimeEmbed()
              .setType(MimeEmbedType.FATAL_ERROR)
              .setTitle("Le bot a été bloqué par l'API")
              .setDescription(
                `${error.message
                  .replace(interaction.token, "TOK3N")
                  .replace(token, "§KRIPT")}\n${error.response.status} ${
                  error.response.statusText
                }`
              )
              .setFooter({ text: "Données par skript-mc.fr" }),
          ],
        });
      } else {
        throw err;
      }
    } else {
      throw err;
    }
  }
}
