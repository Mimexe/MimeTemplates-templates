import { SlashCommandBuilder } from "discord.js";
import { MimeEmbed, MimeEmbedType } from "../utils/MimeEmbed.js";

export const data = new SlashCommandBuilder()
  .setName("ping")
  .setDescription("Savoir le ping du bot");
export async function execute(interaction) {
  const msg = await interaction.channel.send("Ping");
  const bot = Math.floor(msg.createdTimestamp - interaction.createdTimestamp);
  const ws = Math.floor(interaction.client.ws.ping);
  let color = "Grey";
  if (bot < 200) {
    color = "Green";
  } else if (bot < 250) {
    color = "Yellow";
  } else if (bot < 350) {
    color = "Red";
  } else {
    color = "DarkRed";
  }
  const embed = new MimeEmbed()
    .setType(MimeEmbedType.INFO)
    .setTitle("Pong!")
    .setColor(color)
    .setFields([
      { name: "Bot", value: `${bot} ms` },
      { name: "WS", value: `${ws} ms` },
    ]);
  await interaction.reply({ embeds: [embed] });
  await msg.delete();
}
