import { REST, Routes } from "discord.js";
import { warn, success, error as _error, debug } from "./logger.js";
import { readdirSync } from "fs";

export async function loadCommands(client) {
  try {
    // Load commands
    const commands = [];

    const commandFiles = readdirSync(`./commands/`).filter((file) =>
      file.endsWith(".js")
    );

    let done = 0;
    for (const file of commandFiles) {
      const command = await import(`./commands/${file}`);
      if ("data" in command && "execute" in command) {
        if (command.data.name || command.data.description) {
          if (
            command.data.name != "<name>" ||
            command.data.description != "<description>"
          ) {
            client.commands.set(command.data.name, command);
            commands.push(command.data.toJSON());
            done++;
          } else {
            warn(`The command ${file} is not changed.`);
          }
        } else {
          warn(
            `The command ${file} is missing a required "name" or "description" property.`
          );
        }
      } else {
        warn(
          `The command ${file} is missing a required "data" or "execute" property.`
        );
      }
    }

    success(`[Commands] Loaded ${done} commands!`);
    // Register command
    // Construct and prepare an instance of the REST module
    const rest = new REST({ version: "10" }).setToken(client.token);

    // and deploy your commands!
    // The put method is used to fully refresh all commands in the guild with the current set
    const data = await rest.put(
      Routes.applicationGuildCommands(client.user.id, "994618544882995340"),
      { body: commands }
    );

    success(`[Commands] Successfully registered ${data.length} commands!`);
  } catch (error) {
    // And of course, make sure you catch and log any errors!
    _error("Error while loading commands: " + error.stack);
  }
}
export async function loadEvents(client) {
  try {
    const eventFiles = readdirSync("./events/").filter((file) =>
      file.endsWith(".js")
    );

    let done = 0;
    for (const file of eventFiles) {
      const event = await import(`./events/${file}`);
      if ("name" in event && "execute" in event) {
        if (event.once) {
          client.once(event.name, async (...args) => {
            await event.execute(client, ...args);
          });
          done++;
        } else {
          client.on(event.name, async (...args) => {
            await event.execute(client, ...args);
          });
          done++;
        }
      } else {
        warn(
          `The event ${file} is missing a required "event" or "execute" property.`
        );
      }
    }
    success(`[Events] Successfully loaded ${done} events!`);
  } catch (err) {
    _error("Error while loading events: " + err.stack);
  }
}
export async function loadTasks(client) {
  try {
    const taskFiles = readdirSync("./tasks/").filter((file) =>
      file.endsWith(".js")
    );

    let done = 0;
    for (const file of taskFiles) {
      const task = await import(`./tasks/${file}`);
      if ("interval" in task && "execute" in task) {
        if (task.runOnStart) {
          await task.execute(client);
          debug(`[Tasks/${task.name || file}] Executed !`);
        }
        setInterval(async () => {
          await task.execute(client);
          debug(`[Tasks/${task.name || file}] Executed !`);
        }, task.interval);
        done++;
      } else {
        warn(
          `The task ${file} is missing a required "event" or "execute" property.`
        );
      }
    }
    success(`[Tasks] Successfully loaded ${done} task!`);
  } catch (err) {
    _error("Error while loading task: " + err.stack);
  }
}
