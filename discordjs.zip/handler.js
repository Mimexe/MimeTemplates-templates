const { REST, Routes, Client } = require("discord.js");
const logger = require("./logger.js");
const path = require("path");
const fs = require("fs");

module.exports = {
  /**
   * Load and register command
   * @param {Client} client
   */
  loadCommands: async (client) => {
    try {
      // Load commands
      const commands = [];

      const commandsPath = path.resolve("commands");
      const commandFiles = fs
        .readdirSync(commandsPath)
        .filter((file) => file.endsWith(".js"));

      for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ("data" in command && "execute" in command) {
          if (command.data.name || command.data.description) {
            if (
              command.data.name != "name" ||
              command.data.description != "description"
            ) {
              client.commands.set(command.data.name, command);
              commands.push(command.data.toJSON());
            } else {
              logger.warn(`The command at ${filePath} is not changed.`);
            }
          } else {
            logger.warn(
              `The command at ${filePath} is missing a required "name" or "description" property.`
            );
          }
        } else {
          logger.warn(
            `The command at ${filePath} is missing a required "data" or "execute" property.`
          );
        }
      }
      // Register command
      // Construct and prepare an instance of the REST module
      const rest = new REST({ version: "10" }).setToken(client.token);

      // and deploy your commands!

      // The put method is used to fully refresh all commands in the guild with the current set
      const data = await rest.put(
        Routes.applicationGuildCommands(client.user.id, "1032345208068767764"),
        { body: commands }
      );

      logger.success(`[Commands] Successfully loaded ${data.length} commands!`);
    } catch (error) {
      // And of course, make sure you catch and log any errors!
      logger.error("Error while loading commands: " + error.stack);
    }
  },
  /**
   * Load event
   * @param {Client} client
   */
  loadEvents: async (client) => {
    try {
      const eventsPath = path.join(__dirname, "events");
      const eventFiles = fs
        .readdirSync(eventsPath)
        .filter((file) => file.endsWith(".js"));

      let done = 0;
      for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if ("name" in event && "execute" in event) {
          if (event.once) {
            client.once(event.name, async (...args) => {
              await event.execute(client, ...args);
            });
            done++;
          } else {
            client.on(event.name, async (...args) => {
              await event.execute(client, ...args);
            });
            done++;
          }
        } else {
          logger.warn(
            `The event at ${filePath} is missing a required "event" or "execute" property.`
          );
        }
      }
      logger.success(`[Events] Successfully loaded ${done} events!`);
    } catch (err) {
      logger.error("Error while loading events: " + err.stack);
    }
  },
  /**
   *
   * @param {Client} client
   */
  loadTasks: async (client) => {
    try {
      const tasksPath = path.join(__dirname, "tasks");
      const taskFiles = fs
        .readdirSync(tasksPath)
        .filter((file) => file.endsWith(".js"));

      let done = 0;
      for (const file of taskFiles) {
        const filePath = path.join(tasksPath, file);
        const task = require(filePath);
        if ("interval" in task && "execute" in task) {
          if (task.runOnStart) {
            await task.execute(client);
            logger.debug(`[Tasks/${task.name || file}] Executed !`);
          }
          setInterval(async () => {
            await task.execute(client);
            logger.debug(`[Tasks/${task.name || file}] Executed !`);
          }, task.interval);
          done++;
        } else {
          logger.warn(
            `The event at ${filePath} is missing a required "event" or "execute" property.`
          );
        }
      }
      logger.success(`[Tasks] Successfully loaded ${done} task!`);
    } catch (err) {
      logger.error("Error while loading task: " + err.stack);
    }
  },
};
