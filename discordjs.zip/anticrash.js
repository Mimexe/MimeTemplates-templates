const logger = require("./logger");

module.exports = {
  init: async (process, client) => {
    process.on("unhandledRejection", (reason) => {
      logger.error(`[AntiCrash] Unhandled Rejection on promise: ${reason}`);
    });

    process.on("uncaughtException", (error, origin) => {
      logger.error(
        `[AntiCrash] Uncaught Exception: ${error.stack.toString()}\n${origin.toString()}`
      );
    });

    client.on("error", function (error) {
      logger.error(
        `Client's WebSocket encountered a connection error: ${error}`
      );
    });

    client.on("shardDisconnect", function (event, id) {
      logger.debug(`shard with id ${id} has disconnected`);
    });

    client.on("shardError", function (error, shardId) {
      logger.error(`a shard ${shardId} encountered a connection error`);
      logger.error(error.stack);
    });

    client.on("shardReady", function (id, unavailableGuilds) {
      logger.debug(`a shard ${id} turned ready`);
      logger.debug(unavailableGuilds);
    });

    client.on("shardReconnecting", function (id) {
      logger.debug(
        `a shard with id ${id} is attempting to reconnect or re-identify`
      );
    });

    client.on("shardResume", function (id, replayedEvents) {
      logger.debug(`a shard ${id} resumes successfully`);
      logger.debug(replayedEvents);
    });
  },
};
