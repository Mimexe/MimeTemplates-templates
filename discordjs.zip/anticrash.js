import { error as _error, debug } from "./logger.js";

export async function init(process, client) {
  process.on("unhandledRejection", (reason) => {
    _error(
      `[AntiCrash] Unhandled Rejection on promise: ${
        reason?.stack ? reason.stack : reason
      }`
    );
  });

  process.on("uncaughtException", (error, origin) => {
    _error(
      `[AntiCrash] Uncaught Exception: ${error?.code ? error.code : "XXX"} ${
        error?.stack ? error.stack : error
      }`
    );
  });

  client.on("shardDisconnect", function (event, id) {
    debug(`shard with id ${id} has disconnected`);
  });

  client.on("shardError", function (error, shardId) {
    _error(`a shard ${shardId} encountered a connection error`);
    _error(error.stack);
  });

  client.on("shardReady", function (id, unavailableGuilds) {
    debug(`a shard ${id} turned ready`);
    debug(unavailableGuilds);
  });

  client.on("shardReconnecting", function (id) {
    debug(`a shard with id ${id} is attempting to reconnect or re-identify`);
  });

  client.on("shardResume", function (id, replayedEvents) {
    debug(`a shard ${id} resumes successfully`);
    debug(replayedEvents);
  });
}
