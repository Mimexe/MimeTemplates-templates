let enabled = false;

module.exports = (en) => {
  if (en != undefined) {
    enabled = en;
    return;
  }
  return enabled;
};
