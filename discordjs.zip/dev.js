let enabled = false;

export default (en) => {
  if (en != undefined) {
    enabled = en;
    return;
  }
  return enabled;
};
