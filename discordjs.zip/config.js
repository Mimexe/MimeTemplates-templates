export const token = "<TOKEN_DISCORD>";
