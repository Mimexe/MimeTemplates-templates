module.exports = {
  token: "<INSERT TOKEN>",
};
