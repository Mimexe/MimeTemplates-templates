const { Client, Collection, Events } = require("discord.js");
const logger = require("./logger.js");
const config = require("./config.js");
const handler = require("./handler.js");
const fs = require("fs");
const anticrash = require("./anticrash");
const isDev = require("./dev.js");
logger.info("Starting...");
if (process.argv.includes("--dev")) {
  isDev(true);
  logger.info("Starting in developpement mode.");
}

const client = new Client({
  intents: 131071,
});
anticrash.init(process, client);

client.commands = new Collection();

client.on(Events.ClientReady, async () => {
  client.fullReady = false;
  await handler.loadEvents(client);
  await handler.loadCommands(client);
  await handler.loadTasks(client);
  client.fullReady = true;
  logger.success(`Ready! Logged in as ${client.user.tag}`);
});

process.on("SIGINT", async () => {
  await new Promise((r) => {
    client.once("shardDisconnect", () => {
      r();
    });
    client.destroy();
  });
  process.exit(0);
});

process.on("exit", (code) => {
  logger.info("Exitted with code " + code);
});

client.login(config.token);
