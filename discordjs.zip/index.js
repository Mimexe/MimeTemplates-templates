import { Client, Collection, Events } from "discord.js";
import { info, success } from "./logger.js";
import { token } from "./config.js";
import { loadEvents, loadCommands, loadTasks } from "./handler.js";
import { init } from "./anticrash.js";
import isDev from "./dev.js";
info("Starting...");
if (process.argv.includes("--dev")) {
  isDev(true);
  info("Starting in developpement mode.");
}

const client = new Client({
  intents: 131071,
});
init(process, client);

client.commands = new Collection();

client.on(Events.ClientReady, async () => {
  client.fullReady = false;
  await loadEvents(client);
  await loadCommands(client);
  await loadTasks(client);
  client.user.setStatus(isDev() ? "dnd" : "online");
  client.fullReady = true;
  success(`Ready! Logged in as ${client.user.tag}`);
});

process.on("SIGINT", async () => {
  await new Promise((r) => {
    client.once("shardDisconnect", () => {
      r();
    });
    client.destroy();
  });
  process.exit(0);
});

process.on("exit", (code) => {
  info("Exitted with code " + code);
});

client.login(token);
